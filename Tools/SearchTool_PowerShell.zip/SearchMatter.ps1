Param (
	[Parameter(Mandatory=$True)]
	[String]$Drive,
	[Parameter(Mandatory=$True)]
	[String]$SearchWhat
)
## $ErrorActionPreference = "SilentlyContinue"
If (Test-Path "CheckMe.csv") {
	Remove-Item "CheckMe.csv"
}
If ($Drive) {
	If ($SearchWhat -IEQ "All") {
		Get-ChildItem "$Drive\" -Recurse -Force | Select-Object Name, @{Name="Path";Expression={$_.FullName}}, CreationTime, LastWriteTime | Sort-Object Name | Export-CSV -Path "CheckMe.csv" -NoTypeInformation
	}
	Else {
		$Res = (Get-ChildItem "$Drive\" -Recurse -Force | Where-Object {($_.Name -Like $SearchWhat)} | Measure-Object).Count
		If ($Res -GT 0) {
			Get-ChildItem "$Drive\" -Recurse -Force | Where-Object {($_.Name -Like $SearchWhat)} | Select-Object Name, @{Name="Path";Expression={$_.FullName}}, CreationTime, LastWriteTime | Sort-Object Name | Export-CSV -Path "CheckMe.csv" -NoTypeInformation
		}
		Else {
			If (Test-Path "CheckMe.csv") {
				Remove-Item "CheckMe.csv"
			}
		}
	}
}